# Confluent Kafka — mTLS with Self-Signed CA — Ansible Playbooks

A complete, production-grade Ansible project that deploys the full **Confluent Platform 7.7**
stack on Linux with **mutual TLS (mTLS)** enforced on every connection — broker listeners,
ZooKeeper, Schema Registry, Kafka Connect, ksqlDB, and Control Center — using a
self-signed Root CA generated at deploy time.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                          Root CA  (self-signed)                     │
│                     /tmp/confluent-certs/ca/ca.crt                  │
└──────────────────────────┬──────────────────────────────────────────┘
                           │  Signs all leaf certs
          ┌────────────────┼────────────────────────────────┐
          │                │                                │
    ZooKeeper         Kafka Brokers               All Components
  (TLS + quorum TLS)  (SSL-only listeners)   (SR / Connect / ksqlDB / C3)
  clientAuth=need     clientAuth=required      HTTPS + clientAuth=required
```

**All plaintext ports are disabled.** Every service-to-service and
client-to-broker connection requires a certificate issued by the Root CA.

---

## Directory Structure

```
confluent-kafka-mtls/
├── site.yml                          # Master playbook (all phases)
├── rotate-certs.yml                  # Rolling cert rotation
├── validate.yml                      # End-to-end mTLS smoke tests
├── inventory/
│   └── hosts.ini                     # Edit with your hostnames
├── group_vars/
│   └── all.yml                       # All variables (passwords, ports, versions)
└── roles/
    ├── generate_certs/               # Phase 1: CA + leaf certs (runs on localhost)
    ├── common/                       # Phase 2: Java, repo, cert deployment
    ├── kafka_zookeeper/              # Phase 3: ZooKeeper TLS
    ├── kafka_broker/                 # Phase 4: Kafka broker mTLS
    ├── schema_registry/              # Phase 5: Schema Registry HTTPS
    ├── kafka_connect/                # Phase 6: Connect HTTPS + mTLS
    ├── ksqldb/                       # Phase 7: ksqlDB HTTPS
    └── control_center/               # Phase 8: Control Center HTTPS
```

---

## Prerequisites

### Ansible Controller
```bash
# Python dependencies
pip3 install ansible

# Required Ansible collections
ansible-galaxy collection install community.crypto
ansible-galaxy collection install ansible.posix

# Java keytool must be on PATH (for JKS keystore creation)
which keytool
```

### Target Hosts
- Ubuntu 20.04/22.04 or RHEL/CentOS 8/9
- Python 3 installed
- SSH access with sudo/become
- Open ports (see Port Reference below)

---

## Quick Start

### 1. Edit inventory
```ini
# inventory/hosts.ini
[zookeeper]
zk1.mycompany.com
zk2.mycompany.com
zk3.mycompany.com

[kafka_broker]
kafka1.mycompany.com
kafka2.mycompany.com
kafka3.mycompany.com
# ... etc
```

### 2. Change passwords
Edit `group_vars/all.yml` — **never use the defaults in production**:
```yaml
ssl_keystore_store_password: "your-strong-keystore-password"
ssl_keystore_key_password:   "your-strong-key-password"
ssl_truststore_password:     "your-strong-truststore-password"
```

Consider using `ansible-vault encrypt group_vars/all.yml` for the password fields.

### 3. Run
```bash
# Full deployment
ansible-playbook -i inventory/hosts.ini site.yml

# With verbose output
ansible-playbook -i inventory/hosts.ini site.yml -v

# Certs only (no service install)
ansible-playbook -i inventory/hosts.ini site.yml --tags generate_certs

# Skip cert generation (certs already exist)
ansible-playbook -i inventory/hosts.ini site.yml --skip-tags generate_certs

# Single component only
ansible-playbook -i inventory/hosts.ini site.yml --tags kafka
```

### 4. Validate
```bash
ansible-playbook -i inventory/hosts.ini validate.yml
```

---

## mTLS Configuration Details

### What "mutual TLS" means here

| Direction | Client presents cert? | Server verifies client? |
|-----------|----------------------|-------------------------|
| Client → Kafka broker | ✅ Yes (from keystore) | ✅ Yes (`ssl.client.auth=required`) |
| Broker ↔ Broker | ✅ Yes | ✅ Yes |
| Broker → ZooKeeper | ✅ Yes | ✅ Yes (`ssl.clientAuth=need`) |
| ZooKeeper ↔ ZooKeeper (quorum) | ✅ Yes | ✅ Yes (`sslQuorum=true`) |
| Client → Schema Registry | ✅ Yes | ✅ Yes |
| Client → Kafka Connect | ✅ Yes | ✅ Yes |
| Client → ksqlDB | ✅ Yes | ✅ Yes |
| Client → Control Center | ✅ Yes | ✅ Yes |

### Certificate structure per host
```
/etc/kafka/ssl/
├── ca.crt                        # Root CA (public cert — shared across all hosts)
├── <hostname>.key                # Host private key
├── <hostname>.crt                # Host certificate (signed by Root CA)
├── kafka.keystore.jks            # JKS: host key + cert + CA chain
└── kafka.truststore.jks          # JKS: Root CA only
```

### TLS versions and ciphers
All listeners are configured to accept **TLS 1.2 and TLS 1.3 only**.
Cipher suite allow-list (TLS 1.3 preferred):
```
TLS_AES_256_GCM_SHA384
TLS_CHACHA20_POLY1305_SHA256
TLS_AES_128_GCM_SHA256
TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384   (TLS 1.2 fallback)
TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256   (TLS 1.2 fallback)
```

---

## Port Reference

| Service | Port | Protocol | mTLS? |
|---------|------|----------|-------|
| ZooKeeper client (TLS) | 2182 | TLS | Yes (clientAuth=need) |
| ZooKeeper peer | 2888 | TLS | Yes |
| ZooKeeper leader election | 3888 | TLS | Yes |
| Kafka (external / client) | 9093 | SSL | Yes |
| Kafka (internal / broker) | 9091 | SSL | Yes |
| Kafka (replication) | 9092 | SSL | Yes |
| Schema Registry | 8081 | HTTPS | Yes |
| Kafka Connect REST | 8083 | HTTPS | Yes |
| ksqlDB REST | 8088 | HTTPS | Yes |
| Control Center UI | 9021 | HTTPS | Yes |

---

## Certificate Rotation

```bash
# Rotate leaf certs only (CA unchanged, shorter downtime window)
ansible-playbook -i inventory/hosts.ini rotate-certs.yml -e rotate_ca=false

# Rotate everything including Root CA
ansible-playbook -i inventory/hosts.ini rotate-certs.yml -e rotate_ca=true
```

The rotation playbook performs a **rolling restart** (serial: 1) for ZooKeeper
and Kafka brokers to avoid data loss and minimize downtime.

---

## Using the Client Properties File

Kafka clients connecting to this cluster need a similar properties file:

```properties
# client.properties — for kafka-console-producer, consumer, etc.
security.protocol=SSL
ssl.keystore.location=/path/to/client.keystore.jks
ssl.keystore.password=<ssl_keystore_store_password>
ssl.key.password=<ssl_keystore_key_password>
ssl.truststore.location=/path/to/client.truststore.jks
ssl.truststore.password=<ssl_truststore_password>
ssl.endpoint.identification.algorithm=
```

The client's certificate must be signed by the same Root CA
(`/tmp/confluent-certs/ca/ca.crt`). Generate a client cert with:

```bash
# Generate client key
openssl genrsa -out client.key 2048

# Generate CSR
openssl req -new -key client.key -out client.csr \
  -subj "/CN=my-kafka-client/O=MyOrganization"

# Sign with Root CA
openssl x509 -req -in client.csr \
  -CA /tmp/confluent-certs/ca/ca.crt \
  -CAkey /tmp/confluent-certs/ca/ca.key \
  -CAcreateserial -out client.crt -days 730

# Create JKS keystore
keytool -importkeystore \
  -srckeystore <(openssl pkcs12 -export -in client.crt -inkey client.key \
                  -certfile /tmp/confluent-certs/ca/ca.crt \
                  -passout pass:changeit -name client) \
  -srcstoretype PKCS12 -srcstorepass changeit \
  -destkeystore client.keystore.jks -deststorepass changeit -noprompt
```

---

## Security Hardening Checklist

- [x] All plaintext listeners removed (`clientPort=0` in ZooKeeper)
- [x] `ssl.client.auth=required` on all Kafka listeners
- [x] ZooKeeper quorum encrypted (`sslQuorum=true`)
- [x] TLS 1.0 / 1.1 / SSLv3 disabled
- [x] Strong cipher suite allow-list
- [x] Private keys mode `0600`, keystores mode `0640`
- [x] Service accounts own cert directories (cp-kafka, cp-schema-registry, etc.)
- [ ] Rotate passwords from defaults in `group_vars/all.yml`
- [ ] Store passwords in Ansible Vault (`ansible-vault encrypt group_vars/all.yml`)
- [ ] Replace `ssl.endpoint.identification.algorithm=` with `https` when DNS is stable
- [ ] Implement RBAC / ACLs for Kafka topics (separate playbook)
- [ ] Set up certificate expiry monitoring (cert validity: 730 days by default)
